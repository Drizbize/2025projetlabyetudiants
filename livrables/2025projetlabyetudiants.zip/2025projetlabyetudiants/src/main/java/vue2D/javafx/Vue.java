package vue2D.javafx;

import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import labyrinthe.IEtage;
import labyrinthe.ILabyrinthe;
import labyrinthe.ISalle;
import personnages.IPersonnage;
import vue2D.IVue;
import vue2D.AVue;
import vue2D.sprites.ISprite;

/**
 *
 * @author INFO Professors team
 */
public class Vue extends AVue implements IVue {

    Dessin dessin;
    ILabyrinthe labyrinthe;
    public Scene scene;

    public Vue(ILabyrinthe labyrinthe) {
        this.labyrinthe = labyrinthe;
        dessin = new Dessin(labyrinthe, this);
        Group root = new Group();
        this.scene = new Scene(root);
        root.getChildren().add(dessin);
    }
    
    @Override
    public boolean add(ISprite sprite ) {
        super.add(sprite);
        
        if (sprite instanceof EventHandler) {
            System.out.println("registering keylistener");
            this.scene.setOnKeyPressed((EventHandler)sprite);
        }
        
        return true;
    }

    @Override
    public void dessiner() {
        // recopie du fond (image); murs + salles
        dessin.dessinFond();
        // dessin des salles
        
        IEtage e = labyrinthe.getEtageCourant();
        dessin.dessinSalles(e, labyrinthe.getHero());
        dessin.dessinPlusCourtChemin(labyrinthe.getHero());
        dessin.drawSprites(labyrinthe.getHero());
        if (labyrinthe.getHero() == null)
        {
            dessin.drawGameOver();
        }
    }

}
